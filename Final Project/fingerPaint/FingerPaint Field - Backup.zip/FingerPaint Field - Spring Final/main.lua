-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local composer = require("composer")
composer.gotoScene("field")
--initializes the composer file(s). This states to go to the field.lua file first.